NKATHA BEAUTY SALON WEBSITE

Files:
- index.html: complete website

How to publish:
1. Buy a domain and hosting from a provider such as HostingKE or Hostinger.
2. Open the hosting control panel and File Manager.
3. Open the public_html folder.
4. Upload index.html.
5. Visit your domain.

WhatsApp link is already configured for 0793 284 872.
